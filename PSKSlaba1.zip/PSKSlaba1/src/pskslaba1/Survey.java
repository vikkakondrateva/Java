/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pskslaba1;

import javax.swing.*;
import java.util.*;
import java.io.*;          // Для IOException
import java.net.Socket;    // Для Socket
import java.io.PrintWriter; // Для PrintWriter
import java.nio.file.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Вика
 */
public class Survey extends javax.swing.JFrame {
    
    private List<Ask> asks;  // Список вопросов
    private List<Rule> rules; // Список правил
    private List<Answer> userAnswers; // Список ответов пользователя
    private int currentIndex; // Текущий индекс вопроса
    private FPSKSlaba1 parent; // Главное окно
    
    
    public Survey() {
        this.asks = new ArrayList<>();  // Создаем пустой список вопросов
        this.rules = new ArrayList<>();
        this.userAnswers = new ArrayList<>();
        this.currentIndex = 0;
        this.parent = null;

        initComponents();
        getContentPane().setBackground(new java.awt.Color(225, 249, 247));
    }
    

    /**
     * Creates new form Survey
     */
    public Survey(List<Ask> asks, List<Rule> rules, FPSKSlaba1 parent) {
        this.asks = asks;
        this.rules = rules;
        this.userAnswers = new ArrayList<>();
        this.currentIndex = 0;
        this.parent = parent;
        
        initComponents();
        getContentPane().setBackground(new java.awt.Color(225, 249, 247));
        UpdateWindow();
    }
    
    private void sendResultsToServer(String resultText) {
        try (Socket socket = new Socket("localhost", 12345);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
        
            // Удаляем HTML-теги и форматируем для записи
            String plainText = resultText.replace("<html>", "")
                                    .replace("</html>", "")
                                    .replace("<br>", " | ")
                                    .replaceAll("\\<.*?\\>", "");
        
            // Записываем в файл (чистый текст)
            Path path = Paths.get("results.txt");
            String timestamp = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String logEntry = timestamp + " | " + plainText;
            Files.write(path, (logEntry + "\n").getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        
            // Отправляем на сервер (чистый текст)
            out.println(logEntry);
            System.out.println("Результаты отправлены: " + logEntry);
        
        } catch (IOException e) {
            System.err.println("Ошибка: " + e.getMessage());
        }
    }

    private void UpdateWindow() {
        if (currentIndex < asks.size()) {
            jLabel1.setText("Вопрос " + (currentIndex + 1) + " из " + asks.size());
            jLabel2.setText(asks.get(currentIndex).getQuestion());
        } else {
            System.out.println("Ошибка: текущий индекс вышел за границы списка asks.");
        }
    }
     
    private void answerButtonClicked(boolean answer) throws ExecutionException {
        System.out.println("Answer to question number " + (currentIndex + 1) + ": " + (answer ? "Yes" : "No"));

        if (currentIndex < asks.size()) {
            Ask currentAsk = asks.get(currentIndex);
            // Проверяем, существует ли уже ответ на этот вопрос
            Answer userAnswer = null;
            for (Answer ans : userAnswers) {
                if (ans.getId() == currentAsk.getId()) {
                    userAnswer = ans;
                    break;
                }
            }

            // Если ответа еще нет, создаем новый
            if (userAnswer == null) {
                userAnswer = new Answer(currentAsk.getId(), currentAsk.getQuestion(), ""); 
                userAnswers.add(userAnswer);
            }

            // Если ответ "Да", добавляем все conditionId этого вопроса в userAnswer
            if (answer) {
                for (Integer conditionId : currentAsk.getConditionIds()) {
                    userAnswer.addConditionId(conditionId); // Добавляем ID, а не заменяем
                }
            }
        }  
        
        System.out.println("userAnswers: " + userAnswers);
                
        if (currentIndex + 1 < asks.size()) {
            currentIndex++;
            UpdateWindow();
        } else {
            JOptionPane.showMessageDialog(this, "Опрос завершен!", "Конец", JOptionPane.INFORMATION_MESSAGE);
            findBestMatches(parent.getRules(), userAnswers);
            dispose(); // Закрываем окно после завершения опроса
        }
    }

    private void findBestMatches(List<Rule> rules, List<Answer> userAnswers) throws ExecutionException {
    if (rules == null || rules.isEmpty()) {
        System.out.println("Ошибка: список rules пуст!");
        return;
    }

    System.out.println("Начало поиска best совпадений...");

    List<Integer> allConditionIds = getAllConditionIds();
    List<Integer> userConditionIds = getUserConditionIds(userAnswers);

    List<Map.Entry<Double, Rule>> sortedMatches = Collections.synchronizedList(new ArrayList<>());

    // Параллельная обработка
    ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    List<Future<?>> futures = new ArrayList<>();

    for (Rule rule : rules) {
        futures.add(executor.submit(() -> {
            double percentage = calculateMatchPercentage(rule, userConditionIds, allConditionIds);
            if (percentage >= 72) {
                sortedMatches.add(new AbstractMap.SimpleEntry<>(percentage, rule));
            }
        }));
    }

    // Ждём завершения всех задач
    for (Future<?> future : futures) {
        try {
            future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    executor.shutdown();

    // Отображение результатов
    Result resultWindow = new Result();
    resultWindow.setVisible(true);

    String timestamp = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    StringBuilder logEntry = new StringBuilder(timestamp + " | ");

    if (sortedMatches.isEmpty()) {
        String healthyMessage = "Вы здоровы!";
        System.out.println(healthyMessage);
        resultWindow.setResultText(healthyMessage);
        logEntry.append(healthyMessage);
    } else {
        sortedMatches.sort((a, b) -> Double.compare(b.getKey(), a.getKey()));
        StringBuilder resultText = new StringBuilder("<html>");
        for (Map.Entry<Double, Rule> entry : sortedMatches) {
            String matchText = "Вероятность того, что у вас " + entry.getValue().getName() + ": " + String.format("%.2f", entry.getKey()) + "%";
            System.out.println(matchText);
            resultText.append(matchText).append("<br>");
            logEntry.append(matchText).append(" | ");
        }
        resultText.append("</html>");
        resultWindow.setResultText(resultText.toString());
    }

    sendResultsToServer(logEntry.toString());
}

    
    
    
    private double calculateMatchPercentage(Rule rule, List<Integer> userConditionIds, List<Integer> allConditionIds) {
        if (rule == null || allConditionIds.isEmpty()) {
            return 0;
        }

        List<Integer> ruleConditions = rule.getConditionIds();

        int totalConditions = allConditionIds.size();
        int matchCount = 0;

        for (Integer id : allConditionIds) {
            boolean inRule = ruleConditions.contains(id);
            boolean inAnswers = userConditionIds.contains(id);

            if (inRule == inAnswers) {  // Подсчитываем совпадения (1 и 1 или 0 и 0)
                matchCount++;
            }
        }
        System.out.println(matchCount + " " + totalConditions);
        return (double) matchCount / totalConditions * 100;
    }
    
    private List<Integer> getAllConditionIds() {
        List<Integer> allIds = new ArrayList<>();
        for (Rule rule : rules) { 
            for (Integer id : rule.getConditionIds()) {  
                if (!allIds.contains(id)) {
                    allIds.add(id);
                }
            }
        }
        return allIds;
    }

    private List<Integer> getUserConditionIds(List<Answer> userAnswers) {
        List<Integer> userConditionIds = new ArrayList<>();
        for (Answer answer : userAnswers) {
            //System.out.println("CondAnswerId: " + answer.getCondAnswerId());
            for (String idStr : answer.getCondAnswerId().split(";")) {
                idStr = idStr.trim();       //удаляем пробелы
                if (!idStr.isEmpty() && idStr.matches("\\d+")) { // Проверяем, что строка не пустая и это число
                    try {
                        int id = Integer.parseInt(idStr);
                        if (!userConditionIds.contains(id)) {
                            userConditionIds.add(id);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Ошибка преобразования ID: " + idStr);
                    }
                } //else {
                    //System.out.println("Некорректный ID: " + idStr);
                //}
            }
        }
        System.out.println("UserIdConditionList: " + userConditionIds);
        return userConditionIds;
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Номер вопроса");

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Вопрос");

        jButton1.setBackground(new java.awt.Color(125, 202, 233));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jButton1.setText("Да");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(125, 202, 233));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jButton2.setText("Нет");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 197, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(143, 143, 143))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(235, 235, 235))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGap(38, 38, 38))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            answerButtonClicked(false);
        } catch (ExecutionException ex) {
            Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            answerButtonClicked(true);
        } catch (ExecutionException ex) {
            Logger.getLogger(Survey.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Survey.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Survey.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Survey.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Survey.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Survey().setVisible(true);
            }
        });
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
