/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pskslaba1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/**
 *
 * @author Вика
 */
public class Rule {
    private int id;
    private String category;
    private String name;
    private List<Integer> conditionIds;

    public Rule(int id, String category, String name, List<Integer> conditionIds) {
        this.id = id;
        this.category = category;
        this.name = name;
        this.conditionIds = conditionIds;
    }
    
    public int getId() {
        return id;
    }
    
    public String getCategory() {
        return category;
    }
    
    public String getName() {
        return name;
    }
    
    public List<Integer> getConditionIds() {
        return conditionIds;
    }

    public void setConditionIds(List<Integer> conditionIds) {
        this.conditionIds = new ArrayList<>(conditionIds); // Копируем список, чтобы избежать изменений по ссылке
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getConditionIdsAsString() {
        return conditionIds.stream()
            .map(String::valueOf)  // Преобразует каждый Integer в String
            .collect(Collectors.joining(",")); // Объединяет их через запятую
    }
    
    
    
    


    @Override
    public String toString() {
        return "Rule{" +
                "id=" + id +
                ", category='" + category + '\'' +
                ", name='" + name + '\'' +
                ", conditionIds=" + conditionIds +
                '}';
    }
}
