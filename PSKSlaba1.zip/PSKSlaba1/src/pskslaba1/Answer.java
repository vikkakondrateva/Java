/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pskslaba1;

/**
 *
 * @author Вика
 */
public class Answer {
    private int id;
    private String name;
    private String category;
    private String condAnswerId; // Строка с номерами утверждений
    private Double percent;
    
    public Answer(int id, String name, String category) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.condAnswerId = "";
        this.percent = null; // Пока не трогаем
    }

    public void addConditionId(int conditionId) {
        if (condAnswerId.isEmpty()) {
            condAnswerId = String.valueOf(conditionId);
        } else {
            condAnswerId += ";" + conditionId;
        }
    }

    public void printCondAnswerId() {
        System.out.println("Ответы пользователя (condAnswerId): " + condAnswerId);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getCondAnswerId() {
        return condAnswerId;
    }

    public Double getPercent() {
        return percent;
    }

    public void setPercent(Double percent) {
        this.percent = percent;
    }
   
    public String toString() {
        return "Answer{id=" + id + ", name='" + name + "', category='" + category + "', condAnswerId='" + condAnswerId + "'}";
    }
}
