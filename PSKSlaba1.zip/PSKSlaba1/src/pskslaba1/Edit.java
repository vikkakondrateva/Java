/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pskslaba1;

import javax.swing.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;  // Для работы со списками
import java.io.*;  // Для работы с файлами (File, FileReader, FileWriter, BufferedReader, BufferedWriter)
import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Font;

/**
 *
 * @author Вика
 */
public class Edit extends javax.swing.JFrame {
    
    private List<Rule> rules;
    private List<Condition> conditions;
    private List<Ask> asks;
    private String filename;
    private String filepath;
    

    /**
     * Creates new form Edit
     */
    public Edit(List<Rule> rules, List<Condition> conditions, List<Ask> asks, String filename, String filepath) {
        this.rules = rules;
        this.conditions = conditions;
        this.asks = asks;
        this.filename = filename;
        this.filepath = filepath;
        
        
        printData(); // Выводим данные в консоль
        initComponents();
        getContentPane().setBackground(new java.awt.Color(225, 249, 247));
        getContentPane().setBackground(new java.awt.Color(225, 249, 247));
        
        JTableHeader header1 = jTable1.getTableHeader();
        header1.setBackground(new Color(161, 227, 238));
        header1.setForeground(new Color(13, 14, 57));
        header1.setFont(new Font("Bahnschrift", Font.PLAIN, 12));
        
        JTableHeader header2 = jTable2.getTableHeader();
        header2.setBackground(new Color(161, 227, 238));
        header2.setForeground(new Color(13, 14, 57));
        header2.setFont(new Font("Bahnschrift", Font.PLAIN, 12));
        
        JTableHeader header3 = jTable3.getTableHeader();
        header3.setBackground(new Color(161, 227, 238));
        header3.setForeground(new Color(13, 14, 57));
        header3.setFont(new Font("Bahnschrift", Font.PLAIN, 12));
        
        
        fillTables(); // Заполняем таблицы
    }
    
    public Edit() {
        this.rules = null;
        this.conditions = null;
        this.asks = new ArrayList<>();
        
        System.out.println("parametrov net");
        initComponents();
    }
       

    
    private void printData() {
        System.out.println("\nFile: " + (filename != null ? filename : "No information"));
        System.out.println("Path: " + (filepath != null ? filepath : "No information"));
    
        System.out.println("Transmited rules:");
        for (Rule rule : rules) {
            System.out.println(rule);
        }

        System.out.println("\nTransmited conditions:");
        for (Condition condition : conditions) {
            System.out.println(condition);
        }
        
        System.out.println("\nTransmitted asks:");
        for (Ask ask : asks) {
            System.out.println(ask);
        }
    }
    
    public void updateRulesTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Очищаем таблицу

        for (Rule rule : rules) {
            model.addRow(new Object[]{rule.getName()});
        }
    }
    
    public void updateConditionsTable() {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0); // Очистка таблицы перед обновлением

        for (Condition condition : conditions) {
            model.addRow(new Object[]{condition.getName()});
        }
    }
    
    public void updateAsksTable() {
        
        DefaultTableModel modelAsks = (DefaultTableModel) jTable3.getModel();
        modelAsks.setRowCount(0); // Очищаем таблицу перед обновлением

        for (Ask ask : asks) {
            for (int conditionId : ask.getConditionIds()) {
                Condition condition = findConditionById(conditionId);
                if (condition != null && condition.getName() != null && !condition.getName().trim().isEmpty()) {
                    modelAsks.addRow(new Object[]{ask.getQuestion(), condition.getName()});
                }
            }
        }
        
        //for (Condition condition : conditions) {
            //String questionText = ""; // По умолчанию пусто

            // Ищем соответствующий вопрос по ID утверждения
            //for (Ask ask : asks) {
                //if (ask.getId() == condition.getId()) {
                    //questionText = ask.getQuestion();
                    //break;
                //}
            //}

            // Добавляем строку в таблицу (если утверждение есть, но вопроса нет, то оставляем пустым)
            //modelAsks.addRow(new Object[]{questionText, condition.getName()});
        //}
                
    }
    
// Метод для поиска названия утверждения по ID
//private String getConditionNameById(int conditionId) {
//    for (Condition condition : conditions) {
//        if (condition.getId() == conditionId) {
//            return condition.getName();
//        }
//    }
//    return "Неизвестное утверждение"; // На случай ошибки
//}
private Condition findConditionById(int id) {
    for (Condition condition : conditions) {
        if (condition.getId() == id) {
            return condition;
        }
    }
    return null; // Если утверждение не найдено
}     
        
    private void fillTables() {
        DefaultTableModel modelRules = (DefaultTableModel) jTable1.getModel();
        DefaultTableModel modelConditions = (DefaultTableModel) jTable2.getModel();
        DefaultTableModel modelAsks = (DefaultTableModel) jTable3.getModel();
        
        // Очищаем таблицы перед заполнением
        modelRules.setRowCount(0);
        modelConditions.setRowCount(0);
        modelAsks.setRowCount(0); // Очищаем таблицу перед обновлением

        // Заполняем таблицу правил
        for (Rule rule : rules) {
            modelRules.addRow(new Object[]{rule.getName()}); // Добавляем строку
        }

        // Заполняем таблицу утверждений
        for (Condition condition : conditions) {
            modelConditions.addRow(new Object[]{condition.getName()});
        }
        
        // Создаем отображаемый список вопросов и утверждений
        for (Ask ask : asks) {
            String questionText = ask.getQuestion(); // Берем сам вопрос

            // Перебираем все ID условий, связанных с этим вопросом
            for (int conditionId : ask.getConditionIds()) {
                Condition condition = findConditionById(conditionId);

                // Проверяем, что и вопрос, и утверждение существуют
                if (questionText != null && !questionText.trim().isEmpty() &&
                    condition != null && condition.getName() != null && !condition.getName().trim().isEmpty()) {

                    // Добавляем строку в таблицу
                    modelAsks.addRow(new Object[]{questionText, condition.getName()});
                }
            }
        }
        
    }
    
    private void saveRulesToFile() {
        if (filepath == null || filename == null) {
            // Если файл не выбран, предложить сохранить в новый
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Выберите место для сохранения базы знаний");

            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File newFile = fileChooser.getSelectedFile();
                filename = newFile.getName();
                filepath = newFile.getAbsolutePath();

                try {
                    if (newFile.createNewFile()) {
                        JOptionPane.showMessageDialog(this, "Файл создан: " + newFile.getAbsolutePath());
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(this, "Ошибка при создании файла!", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                return; // Если пользователь отменил, ничего не делаем
            }
        }

        // Теперь записываем правила в файл
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath))) {
            for (Rule rule : rules) {
                // Формируем строку в нужном формате
                String ruleString = String.format(
                    "rule(%d; %s; %s; %s)",
                    rule.getId(),
                    rule.getCategory(),
                    rule.getName(),
                    rule.getConditionIds().toString()
                );
            
                writer.write(ruleString);
                writer.newLine();
            }
            
            writer.newLine();
            
            // Записываем утверждения (Conditions)
            for (Condition condition : conditions) {
                String conditionString = String.format(
                    "cond(%d; %s)",
                    condition.getId(),
                    condition.getName()
                );
                writer.write(conditionString);
                writer.newLine();
            }
            
            writer.newLine();
             
             for (Ask ask : asks) {
                String conditionIdsString = ask.getConditionIds().toString().replace(" ", ""); // Убираем пробелы
                String askString = String.format(
                    "ask(%d; %s; %s)",
                    ask.getId(),
                    ask.getQuestion(),
                    conditionIdsString
                );
                writer.write(askString);
                writer.newLine();
            }

            writer.newLine();
             
            // Записываем информацию о файле
            String knowledgeBaseInfo = String.format("knowledge_base_file: %s", filename);
            writer.write(knowledgeBaseInfo);
            writer.newLine();
            
            
            JOptionPane.showMessageDialog(this, "База знаний успешно сохранена!", "Успех", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Ошибка при сохранении файла!", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }




    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTable1.setBackground(new java.awt.Color(184, 240, 236));
        jTable1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(13, 14, 57));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Объекты"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        jTable2.setBackground(new java.awt.Color(184, 240, 236));
        jTable2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jTable2.setForeground(new java.awt.Color(13, 14, 57));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Утверждения"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
        }

        jButton1.setBackground(new java.awt.Color(125, 202, 233));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(13, 14, 57));
        jButton1.setText("Добавить");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(125, 202, 233));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(13, 14, 57));
        jButton2.setText("Изменить");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(125, 202, 233));
        jButton3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(13, 14, 57));
        jButton3.setText("Удалить");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(125, 202, 233));
        jButton4.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(13, 14, 57));
        jButton4.setText("Добавить");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(125, 202, 233));
        jButton5.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(13, 14, 57));
        jButton5.setText("Изменить");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(125, 202, 233));
        jButton6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(13, 14, 57));
        jButton6.setText("Удалить");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(125, 202, 233));
        jButton7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(13, 14, 57));
        jButton7.setText("Назад");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(125, 202, 233));
        jButton8.setText("Сохранить");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jTable3.setBackground(new java.awt.Color(184, 240, 236));
        jTable3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jTable3.setForeground(new java.awt.Color(13, 14, 57));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Вопрос", "Утверждение"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
            jTable3.getColumnModel().getColumn(1).setResizable(false);
        }

        jButton9.setBackground(new java.awt.Color(125, 202, 233));
        jButton9.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(13, 14, 57));
        jButton9.setText("Добавить");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(125, 202, 233));
        jButton10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(13, 14, 57));
        jButton10.setText("Изменить");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(125, 202, 233));
        jButton11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton11.setForeground(new java.awt.Color(13, 14, 57));
        jButton11.setText("Удалить");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 31, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 648, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jButton11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton10)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton4)
                            .addComponent(jButton5)
                            .addComponent(jButton9)
                            .addComponent(jButton10))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3)
                    .addComponent(jButton6)
                    .addComponent(jButton11))
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton8))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Добавить объект
        AddObject addObjectWindow = new AddObject(this,rules, conditions);
        addObjectWindow.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // сохраняем изменение в файле
        saveRulesToFile();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // редактировать объект                                     
        // Получаем выбранную строку из таблицы
        int selectedRow = jTable1.getSelectedRow();
        System.out.println("Selected Row: " + selectedRow);
    
        // Проверяем, что строка выбрана
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите элемент для редактирования", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем название правила из выбранной строки таблицы
        String selectedRuleName = (String) jTable1.getValueAt(selectedRow, 0); // 0 - колонка с названием

        // Находим объект Rule по названию
        Rule selectedRule = rules.stream()
            .filter(rule -> rule.getName().equals(selectedRuleName))
            .findFirst()
            .orElse(null);

        if (selectedRule == null) {
            JOptionPane.showMessageDialog(this, "Ошибка: не удалось найти объект!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int objectId = selectedRule.getId(); // Теперь ID определен корректно
        
        System.out.println("Selected Row: " + selectedRow);
        System.out.println("Object ID: " + objectId);

        // Ищем объект с этим id в списке правил
        Rule ruleToEdit = rules.stream()
            .filter(rule -> rule.getId() == objectId)
            .findFirst()
            .orElse(null);


        // Если объект найден, открываем окно редактирования
        if (ruleToEdit != null) {
            // Передаем найденный объект в EditObject для редактирования
            EditObject editObject = new EditObject(this, rules, conditions, ruleToEdit);
            editObject.setVisible(true);  // Показываем окно редактирования
        } else {
            // Если объект с таким id не найден, выводим ошибку
            JOptionPane.showMessageDialog(this, "Объект с таким id не найден", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        /// Получаем выбранную строку
        int selectedRow = jTable1.getSelectedRow();
    
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите элемент для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем имя объекта из таблицы
        String ruleName = (String) jTable1.getValueAt(selectedRow, 0);

        // Ищем объект Rule с этим именем
        Rule ruleToRemove = null;
        for (Rule rule : rules) {
            if (rule.getName().equals(ruleName)) {
                ruleToRemove = rule;
                break;
            }
        }

        if (ruleToRemove != null) {
            // Подтверждение удаления
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Вы уверены, что хотите удалить " + ruleToRemove.getName() + "?", 
                "Подтверждение удаления", JOptionPane.YES_NO_OPTION);
        
            if (confirm == JOptionPane.YES_OPTION) {
                rules.remove(ruleToRemove); // Удаляем из списка
                updateRulesTable(); // Обновляем таблицу
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ошибка: Объект не найден", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
         // Получаем выбранную строку в таблице утверждений (jTable2)
        int selectedRow = jTable2.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите утверждение для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем имя утверждения из таблицы
        String conditionName = (String) jTable2.getValueAt(selectedRow, 0);

        // Ищем объект Condition с этим именем
        Condition conditionToRemove = null;
        for (Condition condition : conditions) {
            if (condition.getName().equals(conditionName)) {
                conditionToRemove = condition;
                break;
            }
        }

        if (conditionToRemove != null) {
            // Подтверждение удаления
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Вы уверены, что хотите удалить утверждение: " + conditionToRemove.getName() + "?", 
                "Подтверждение удаления", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                int conditionIdToRemove = conditionToRemove.getId(); // ID удаляемого утверждения
                conditions.remove(conditionToRemove); // Удаляем из списка
                updateConditionsTable(); // Обновляем таблицу утверждений
                
                // Удаляем соответствующий вопрос (Ask) из списка
                Ask askToRemove = null;
                for (Ask ask : asks) {
                    if (ask.getId() == conditionIdToRemove) {
                        askToRemove = ask;
                        break;
                    }
                }

                if (askToRemove != null) {
                    asks.remove(askToRemove); // Удаляем из списка вопросов
                }

                updateAsksTable(); // Обновляем таблицу вопросов
                
                // Удаляем ID утверждения из всех правил
                for (Rule rule : rules) {
                    List<Integer> updatedConditionIds = new ArrayList<>(rule.getConditionIds());
                    updatedConditionIds.removeIf(id -> id == conditionIdToRemove); // Удаляем ID
                    rule.setConditionIds(updatedConditionIds); // Обновляем rule
                }

            // Обновляем таблицу правил
                updateRulesTable();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ошибка: Утверждение не найдено", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int selectedRow = jTable2.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите утверждение для редактирования", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем название утверждения из таблицы
        String selectedConditionName = (String) jTable2.getValueAt(selectedRow, 0); // 0 - колонка с названием

        // Находим объект Condition по названию
        Condition selectedCondition = conditions.stream()
            .filter(condition -> condition.getName().equals(selectedConditionName))
            .findFirst()
            .orElse(null);

        if (selectedCondition == null) {
            JOptionPane.showMessageDialog(this, "Ошибка: не удалось найти утверждение!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int conditionId = selectedCondition.getId(); // Получаем правильный ID

        System.out.println("Condition ID: " + conditionId);

        // Открываем окно редактирования
        EditCond editCondWindow = new EditCond(this, conditions, conditionId);
        editCondWindow.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        EditCond editCondWindow = new EditCond(this, conditions, null); // Передаем null для нового условия
        editCondWindow.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        AddAsk addAskWindow = new AddAsk(this, asks, conditions);
        addAskWindow.setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
         // Получаем выделенную строку
        int selectedRow = jTable3.getSelectedRow();
    
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите вопрос для редактирования!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем текст вопроса из таблицы
        String questionText = (String) jTable3.getValueAt(selectedRow, 0);

        // Ищем вопрос в списке asks по тексту (можно по ID, если он хранится в таблице)
        Ask selectedAsk = null;
        for (Ask ask : asks) {
            if (ask.getQuestion().equals(questionText)) {
                selectedAsk = ask;
                break;
            }
        }

        if (selectedAsk == null) {
            JOptionPane.showMessageDialog(this, "Ошибка: Вопрос не найден!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Создаем список утверждений, которые можно выбрать (только те, у которых нет вопросов, + текущее)
        List<Condition> availableConditions = new ArrayList<>();
        for (Condition condition : conditions) {
            boolean hasAsk = false;
            for (Ask ask : asks) {
                if (ask.getConditionIds().contains(condition.getId()) && ask.getId() != selectedAsk.getId()) {
                    hasAsk = true;
                    break;
                }
            }
            if (!hasAsk || selectedAsk.getConditionIds().contains(condition.getId())) {
            availableConditions.add(condition);
            }
        }
        
        // Открываем окно редактирования с выбранным вопросом
        EditAsk editAskWindow = new EditAsk(this, asks, availableConditions, selectedAsk.getId());
        editAskWindow.setVisible(true);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // Получаем выбранную строку в таблице вопросов
        int selectedRow = jTable3.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите вопрос для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Получаем текст вопроса и утверждения из таблицы
        String questionText = (String) jTable3.getValueAt(selectedRow, 0);
        String conditionText = (String) jTable3.getValueAt(selectedRow, 1);

        // Находим соответствующий объект Ask
        Ask askToRemove = null;
        for (Ask ask : asks) {
            if (ask.getQuestion().equals(questionText)) {
                askToRemove = ask;
                break;
            }
        }

        if (askToRemove != null) {
            // Подтверждение удаления
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Вы уверены, что хотите удалить вопрос: \"" + askToRemove.getQuestion() + "\"?", 
                "Подтверждение удаления", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                asks.remove(askToRemove); // Удаляем из списка
                updateAsksTable(); // Обновляем таблицу вопросов
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ошибка: Вопрос не найден", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new Edit().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    // End of variables declaration//GEN-END:variables
}
