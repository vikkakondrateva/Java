/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pskslaba1;

import java.io.*;
import java.net.*;
import java.nio.file.*;

/**
 *
 * @author Вика
 */
public class SurveyServer {
    private static final int PORT = 12345;
    private static final String LOG_FILE = "results.txt";

    public static void main(String[] args) {
        System.out.println("Сервер логов запущен на порту " + PORT);
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Ошибка сервера: " + e.getMessage());
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
            
            String command = in.readLine();
            if ("GET_LOGS".equals(command)) {
                sendLogFile(out);
            }
        } catch (IOException e) {
            System.err.println("Ошибка клиента: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Ошибка закрытия сокета: " + e.getMessage());
            }
        }
    }

    private static void sendLogFile(PrintWriter out) {
        try {
            // Полный путь к файлу в папке проекта
            String projectDir = System.getProperty("user.dir");
            Path path = Paths.get(projectDir, "results.txt");
        
            System.out.println("Ищу файл по пути: " + path); // Для отладки
        
            if (Files.exists(path)) {
                System.out.println("Файл найден, отправляю содержимое");
                String content = Files.readString(path);
                out.println(content);
            } else {
                System.out.println("Файл не найден");
                out.println("Файл логов не найден по пути: " + path);
            }
        } catch (IOException e) {
            System.err.println("Ошибка при работе с файлом: " + e.getMessage());
            out.println("Ошибка сервера при чтении логов");
        }
    }
}
