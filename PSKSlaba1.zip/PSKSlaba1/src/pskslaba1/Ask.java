/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pskslaba1;

import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author Вика
 */
public class Ask {
    
    private List<Ask> asks = new ArrayList<>();
    private int id;  // ID утверждения
    private String question;  // Текст вопроса
    private List<Integer> conditionIds; // Список ID утверждений, связанных с вопросом

    public Ask(int id, String question, List<Integer> conditionIds) {
        this.id = id;
        this.question = question;
        this.conditionIds = new ArrayList<>(conditionIds);
    }

    public int getId() {
        return id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
    
    public List<Integer> getConditionIds() {
        return conditionIds;
    }

    public void setConditionIds(List<Integer> conditionIds) {
        this.conditionIds = new ArrayList<>(conditionIds);
    }    

    @Override
    public String toString() {
        return "Ask{id=" + id + ", question='" + question + "', conditionIds=" + conditionIds + "}";
    }
}
